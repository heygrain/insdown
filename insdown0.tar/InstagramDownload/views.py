from django.shortcuts import render
import re
import requests
import os
import json

# Create your views here.
def home(request):
    world = "Happy World!"
    return render(request, 'home.html', {"w": world})


def g(request):
    def download(code, proxy='./proxy.json', retry=3):
        n = retry + 1

        # set proxy
        try:
            with open(proxy) as f:
                proxy = json.load(f)
            if proxy['use_proxy']:
                proxy_str = "{}://{}:{}".format(proxy['protocol'],
                                                proxy['address'],
                                                proxy['port'])
                proxy = {
                    "http": proxy_str,
                    "https": proxy_str
                }
            else:
                proxy = None
        except:
            proxy = None

        # acquire source address
        url = "https://www.instagram.com/p/{}/".format(code)
        for i in range(n):
            try:
                res = requests.get(url, proxies=proxy)
                break
            except:
                if i == n - 1:
                    alert = code + " 连接Ins错误，请重试或at网站管理员检查后台。"
                    return alert, []
                # print("Connection to Instagram failed, retrying...")
        pic_re = r'"display_url":"(.*?)"'
        vid_re = r'"video_url":"(.*?)"'
        res_url = re.findall(vid_re, res.text)
        res_url += re.findall(pic_re, res.text)
        res_url = list(set(res_url))
        res_url = [tmp.encode('utf-8').decode('unicode_escape') for tmp in res_url]
        del res

        # set download path
        file_path = './static/images/user-download'
        if not os.path.exists(file_path):
            # 创建路径
            os.makedirs(file_path)

        # download and write file
        k = len(res_url)
        filelist = []
        for j in range(k):  # "Start to download ({}/{})...".format(j + 1, k)
            res_u = res_url[j]
            suf = r'.*[.](.*?)[?]'
            suffix = re.findall(suf, res_u)[0]
            # if suffix == 'mp4':
            #     print("It's a video and it may take some time...")
            for i in range(n):
                try:
                    r = requests.get(res_u, proxies=proxy, stream=True)
                    # 拼接图片名（包含路径）
                    pathname = '{}{}{}.{}'.format(file_path, os.sep, j + 1, suffix)
                    with open(pathname, 'wb') as f:
                        f.write(r.content)
                    filelist.append(('.' + pathname, suffix))
                    del r
                    break
                except:
                    if i == n - 1:
                        filelist.append((res_url, suffix))  # "All attempts to download the resource ({}/{}) have failed.".format(j + 1, k)
                    else:
                        pass # "Fail to download, retrying ({}/{})...".format(j + 1, k)
        alert = "提取成功，如果部分图片显示失败可点击/复制该图片上方地址至浏览器手动下载。"
        return alert, filelist

    alert = '请输入instagram URL'
    files = None
    if request.method == 'POST':
        try:
            ins_url = request.POST.get('g')
            code_re = r'instagram.com/p/(.*?)/'
            code = re.findall(code_re, ins_url)[0]
            alert, files = download(code)
        except:
            return render(request, 'g.html', {'g': "检查下网址是否正确哦", 'pics': files})
    return render(request, 'g.html', {'g': alert, 'pics': files})