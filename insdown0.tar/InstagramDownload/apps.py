from django.apps import AppConfig


class InstagramdownloadConfig(AppConfig):
    name = 'InstagramDownload'
